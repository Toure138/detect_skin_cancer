from flask import Flask, request, render_template, redirect, url_for, send_from_directory
import tensorflow as tf
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import numpy as np
import os

app = Flask(__name__)

# Chemin du modèle enregistré
MODEL_PATH = 'model.h5'

# Charger le modèle
model = tf.keras.models.load_model(MODEL_PATH)

# Classes de cancer de la peau
class_names = ['actinic keratosis', 'basal cell carcinoma', 'dermatofibroma', 'melanoma', 'nevus', 'pigmented benign keratosis', 'seborrheic keratosis', 'squamous cell carcinoma', 'vascular lesion']

@app.route('/', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        if file:
            file_path = os.path.join('uploads', file.filename)
            file.save(file_path)
            
            # Prétraiter l'image et faire une prédiction
            img = load_img(file_path, target_size=(180, 180))
            img = img_to_array(img)
            img = np.expand_dims(img, axis=0)
            
            # Normaliser l'image
            img = img / 255.0
            
            pred = model.predict(img)
            pred_class = class_names[np.argmax(pred)]
            
            # Afficher les probabilités prédites
            print(f"Predicted probabilities: {pred}")
            print(f"Predicted class: {pred_class}")
            
            return render_template('result.html', prediction=pred_class, filename=file.filename)
    return render_template('index.html')

@app.route('/uploads/<filename>')
def send_file(filename):
    return send_from_directory('uploads', filename)

if __name__ == '__main__':
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    app.run(debug=True)
